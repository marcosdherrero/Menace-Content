advancement revoke @s only conures:graves/death

execute unless entity @s[nbt={Health:0f}] run return 0
execute unless predicate conures:graves/within_world_bounds run return 0

# Test for Drops
tag @e[type=item,distance=..3,nbt={Age:0s},tag=!global.ignore,tag=!smithed.entity] add conures.graves.droppedItem
tag @e[type=experience_orb,distance=..3,nbt={Age:0s},tag=!global.ignore,tag=!smithed.entity] add conures.graves.droppedXP
execute unless entity @e[tag=conures.graves.droppedItem] unless entity @e[tag=conures.graves.droppedXP] run return 0

# Create Grave Entity
summon interaction ~ ~ ~ {width:.7f,height:1.2f,response:true,Tags:["conures.grave","conures.graves.newInteraction","global.ignore","smithed.entity","smithed.strict"]}
summon block_display ~ ~ ~ {block_state:{Name:"minecraft:polished_basalt",Properties:{axis:"z"}},teleport_duration:0,transformation:{translation:[-.35f,-1.2f,-.125f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],scale:[.7f,1.2f,.25f]},Tags:["conures.grave.display","conures.graves.newStone","global.ignore","smithed.entity","smithed.strict"]}
tag @s add conures.graves.spawning_grave
summon text_display ~ ~ ~ {text:["",{selector:"@p[tag=conures.graves.spawning_grave]"},{text:"\'s Grave\nClick to Empty"}],transformation:{translation:[0f,.3f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],scale:[.5f,.5f,0f]},billboard:"vertical",Tags:["conures.grave.display","conures.graves.newText","global.ignore","smithed.entity","smithed.strict"]}
tag @s remove conures.graves.spawning_grave
ride @e[tag=conures.graves.newStone,limit=1] mount @e[tag=conures.graves.newInteraction,limit=1]
ride @e[tag=conures.graves.newText,limit=1] mount @e[tag=conures.graves.newInteraction,limit=1]

# Save Drops to Grave
execute as @e[tag=conures.graves.droppedItem] run data modify entity @e[tag=conures.graves.newInteraction,limit=1] data.conures.grave_inventory append from entity @s Item
kill @e[tag=conures.graves.droppedItem]
scoreboard players set @e[tag=conures.graves.newInteraction] conures.graves.stored_xp 0
execute as @e[tag=conures.graves.droppedXP] store result score @s conures.graves.stored_xp run data get entity @s Value
scoreboard players operation @e[tag=conures.graves.newInteraction,limit=1] conures.graves.stored_xp += @e[tag=conures.graves.droppedXP] conures.graves.stored_xp
kill @e[tag=conures.graves.droppedXP]
rotate @e[tag=conures.graves.newStone,limit=1] ~ 0

tag @e[tag=conures.graves.newInteraction] remove conures.graves.newInteraction
tag @e[tag=conures.graves.newStone] remove conures.graves.newStone
tag @e[tag=conures.graves.newText] remove conures.graves.newText