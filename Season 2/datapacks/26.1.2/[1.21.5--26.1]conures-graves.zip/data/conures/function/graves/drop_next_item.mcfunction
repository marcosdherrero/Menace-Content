# @s: Interaction

loot spawn ~ ~ ~ loot conures:null_item
data modify entity @n[type=item,nbt={Age:0s,Item:{components:{"minecraft:custom_data":{conures:{null_item:1b}}}}}] Item set from entity @s data.conures.grave_inventory[0]
data remove entity @s data.conures.grave_inventory[0]
execute if data entity @s data.conures.grave_inventory[0] run function conures:graves/drop_next_item