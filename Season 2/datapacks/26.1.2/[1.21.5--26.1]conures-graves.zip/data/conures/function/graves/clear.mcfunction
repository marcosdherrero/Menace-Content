tellraw @s {text:"Emptying and removing all graves in loaded chunk region...",color:"yellow"}
execute as @e[type=interaction,tag=conures.grave] at @s run function conures:graves/empty