# @s: Interaction

execute if data entity @s data.conures.grave_inventory[0] run function conures:graves/drop_next_item
execute if score @s conures.graves.stored_xp matches 1.. run summon experience_orb ~ ~ ~ {Tags:["conures.graves.newXP"]}
execute store result entity @e[tag=conures.graves.newXP,limit=1] Value short 1 run scoreboard players get @s conures.graves.stored_xp
tag @e[tag=conures.graves.newXP] remove conures.graves.newXP
execute on passengers run kill @s[tag=conures.grave.display]
kill @s[tag=conures.grave]