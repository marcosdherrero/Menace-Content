advancement revoke @s only conures:graves/click_interaction
execute as @e[predicate=conures:graves/clicked_grave] at @s run function conures:graves/empty